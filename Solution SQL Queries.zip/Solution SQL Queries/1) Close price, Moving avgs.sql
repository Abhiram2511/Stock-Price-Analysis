-- 1. Create a new table named 'bajaj1' containing the date, close price, 20 Day MA and 50 Day MA.
-- (This has to be done for all 6 stocks)

-- bajaj1
USE Assignment;
SET SQL_SAFE_UPDATES = 0;	-- Setting Safe Update mode off
DROP table IF EXISTS bajaj1;	-- Drop table is already exists

-- Create a new table named Bajaj1 having Date, Close_Price, 20 and 50 days moving averages
CREATE TABLE bajaj1 AS
	SELECT 
    STR_TO_DATE(`Date`, "%d-%M-%Y") as `Date`,	-- Converting Date into a better readable format
    Close_Price, 
    AVG(Close_Price) OVER (ORDER BY `Date` ASC ROWS 19 PRECEDING) AS `20 Day MA`,	-- Use Window function with Frames(Precedings) to calculate the moving averages
    AVG(Close_Price) OVER (ORDER BY `Date` ASC ROWS 49 PRECEDING) AS `50 Day MA`
    FROM bajaj 
    WHERE Close_Price IS NOT NULL AND `Date` IS NOT NULL;
    
-- As the operations using keys are much faster due to indexing
-- Setting Date as Primary Key to improve the performance of further operations on this table
ALTER TABLE bajaj1
	ADD PRIMARY KEY (`Date`);
    
SELECT * FROM bajaj1;

-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

-- eicher1
USE Assignment;
SET SQL_SAFE_UPDATES = 0;	-- Setting Safe Update mode off
DROP TABLE IF EXISTS eicher1;	-- Drop table is already exists

-- Create a new table named Eicher1 having Date, Close_Price, 20 and 50 days moving averages
CREATE TABLE eicher1 AS
	SELECT 
    STR_TO_DATE(`Date`, "%d-%M-%Y") as `Date`, -- Converting Date into a better readable format. 
    Close_Price, 
    AVG(Close_Price) OVER (ORDER BY `Date` ASC ROWS 19 PRECEDING) AS `20 Day MA`,	-- Use Window function with Frames(Precedings) to calculate the moving averages
    AVG(Close_Price) OVER (ORDER BY `Date` ASC ROWS 49 PRECEDING) AS `50 Day MA`
    FROM eicher
    WHERE Close_Price IS NOT NULL AND `Date` IS NOT NULL;
    
-- As the operations using keys are much faster due to indexing
-- Setting Date as Primary Key to improve the performance of further operations on this table
ALTER TABLE eicher1
	ADD PRIMARY KEY (`Date`);
    
SELECT * FROM eicher1;

-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

-- hero1
USE Assignment;
SET SQL_SAFE_UPDATES = 0;	-- Setting Safe Update mode off

DROP TABLE IF EXISTS hero1;	-- Drop table is already exists

-- Create a new table named hero1 having Date, Close_Price, 20 and 50 days moving averages
CREATE TABLE hero1 AS
	SELECT 
    STR_TO_DATE(`Date`, "%d-%M-%Y") as `Date`, -- Converting Date into a better readable format. 
    Close_Price, 
    AVG(Close_Price) OVER (ORDER BY `Date` ASC ROWS 19 PRECEDING) AS `20 Day MA`,	-- Use Window function with Frames(Precedings) to calculate the moving averages
    AVG(Close_Price) OVER (ORDER BY `Date` ASC ROWS 49 PRECEDING) AS `50 Day MA`
    FROM hero
    WHERE Close_Price IS NOT NULL AND `Date` IS NOT NULL;
    
-- As the operations using keys are much faster due to indexing
-- Setting Date as Primary Key to improve the performance of further operations on this table

ALTER TABLE hero1
	ADD PRIMARY KEY (`Date`);
    
SELECT * FROM hero1;

-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

-- infosys1
USE Assignment;
SET SQL_SAFE_UPDATES = 0;	-- Setting Safe Update mode off

DROP TABLE IF EXISTS infosys1;	-- Drop table is already exists

-- Create a new table named infosys1 having Date, Close_Price, 20 and 50 days moving averages
CREATE TABLE infosys1 AS
	SELECT 
    STR_TO_DATE(`Date`, "%d-%M-%Y") as `Date`, -- Converting Date into a better readable format. 
    Close_Price, 
    AVG(Close_Price) OVER (ORDER BY `Date` ASC ROWS 19 PRECEDING) AS `20 Day MA`,	-- Use Window function with Frames(Precedings) to calculate the moving averages
    AVG(Close_Price) OVER (ORDER BY `Date` ASC ROWS 49 PRECEDING) AS `50 Day MA`
    FROM infosys
    WHERE Close_Price IS NOT NULL AND `Date` IS NOT NULL;
    
-- As the operations using keys are much faster due to indexing
-- Setting Date as Primary Key to improve the performance of further operations on this table

ALTER TABLE infosys1
	ADD PRIMARY KEY (`Date`);
    
SELECT * FROM infosys1;

-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

-- tcs1
USE Assignment;
SET SQL_SAFE_UPDATES = 0;	-- Setting Safe Update mode off

DROP TABLE IF EXISTS tcs1;	-- Drop table is already exists

-- Create a new table named tcs1 having Date, Close_Price, 20 and 50 days moving averages
CREATE TABLE tcs1 AS
	SELECT 
    STR_TO_DATE(`Date`, "%d-%M-%Y") as `Date`, -- Converting Date into a better readable format. 
    Close_Price, 
    AVG(Close_Price) OVER (ORDER BY `Date` ASC ROWS 19 PRECEDING) AS `20 Day MA`,	-- Use Window function with Frames(Precedings) to calculate the moving averages
    AVG(Close_Price) OVER (ORDER BY `Date` ASC ROWS 49 PRECEDING) AS `50 Day MA`
    FROM tcs
    WHERE Close_Price IS NOT NULL AND `Date` IS NOT NULL;
    
-- As the operations using keys are much faster due to indexing
-- Setting Date as Primary Key to improve the performance of further operations on this table

ALTER TABLE tcs1
	ADD PRIMARY KEY (`Date`);
    
SELECT * FROM tcs1;

-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

-- tvs1
USE Assignment;
SET SQL_SAFE_UPDATES = 0;	-- Setting Safe Update mode off

DROP TABLE IF EXISTS tvs1;	-- Drop table is already exists

-- Create a new table named tvs1 having Date, Close_Price, 20 and 50 days moving averages
CREATE TABLE tvs1 AS
	SELECT 
    STR_TO_DATE(`Date`, "%d-%M-%Y") as `Date`, -- Converting Date into a better readable format. 
    Close_Price, 
    AVG(Close_Price) OVER (ORDER BY `Date` ASC ROWS 19 PRECEDING) AS `20 Day MA`,	-- Use Window function with Frames(Precedings) to calculate the moving averages
    AVG(Close_Price) OVER (ORDER BY `Date` ASC ROWS 49 PRECEDING) AS `50 Day MA`
    FROM tvs
    WHERE Close_Price IS NOT NULL AND `Date` IS NOT NULL;
    
-- As the operations using keys are much faster due to indexing
-- Setting Date as Primary Key to improve the performance of further operations on this table

ALTER TABLE tvs1
	ADD PRIMARY KEY (`Date`);
    
SELECT * FROM tvs1;

-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~