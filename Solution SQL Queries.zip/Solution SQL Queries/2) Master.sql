-- 2. Create a master table containing the date and close price of all the six stocks.
-- (Column header for the price is the name of the stock)

USE Assignment;
SET SQL_SAFE_UPDATES = 0;	-- Setting Safe Update mode off

DROP TABLE IF EXISTS `Master`;

-- Creating a master table having date and close prices of all the six stocks on each day
CREATE TABLE IF NOT EXISTS `Master` AS
	SELECT  baj.`Date` AS `Date`, 
			baj.Close_Price AS Bajaj,
			tcs.Close_Price AS TCS,
			tvs.Close_Price AS TVS,
			inf.Close_Price AS Infosys,
			eic.Close_Price AS Eicher,
			hero.Close_Price AS Hero
    FROM bajaj1 baj 
		INNER JOIN tcs1 tcs ON baj.`Date`=tcs.`Date`
		INNER JOIN tvs1 tvs ON tcs.`Date`=tvs.`Date`
		INNER JOIN infosys1 inf ON tvs.`Date`=inf.`Date`
		INNER JOIN eicher1 eic ON inf.`Date`=eic.`Date`
		INNER JOIN hero1 hero ON eic.`Date`=hero.`Date`;
    
SELECT * FROM `Master`;