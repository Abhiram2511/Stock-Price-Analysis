-- 3. Use the table created in Part(1) to generate buy and sell signal. Store this in another table named 'bajaj2'.
-- Perform this operation for all stocks.

-- bajaj2
USE Assignment;
SET SQL_SAFE_UPDATES = 0;	-- Setting Safe Update mode off
DROP TABLE IF EXISTS bajaj2;
CREATE TABLE IF NOT EXISTS bajaj2 AS	-- Creating a table having Date, close_price and a Signal whether to Buy/Sell/Hold
SELECT `Date`, Close_Price AS `Close Price`,
	CASE
		WHEN (`20 Day MA` > `50 Day MA`)   THEN 'BUY'	-- When the shorter moving average is higher than the longer moving average, it is a signal to BUY.
		WHEN (`20 Day MA` < `50 Day MA`)   THEN 'SELL'	-- When the longer moving average is higher than the shorter moving average, it is a signal to SELL.
		ELSE 'HOLD'		-- If the signal is neither buy nor sell, it is meant to be in hold.
	END AS `Signal`
FROM bajaj1 ;

SELECT * FROM bajaj2;

-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

-- eicher2
USE Assignment;
SET SQL_SAFE_UPDATES = 0;	-- Setting Safe Update mode off
DROP TABLE IF EXISTS eicher2;
CREATE TABLE IF NOT EXISTS eicher2 AS	-- Creating a table having Date, close_price and a Signal whether to Buy/Sell/Hold
SELECT `Date`, Close_Price AS `Close Price`,
	CASE
		WHEN (`20 Day MA` > `50 Day MA`)   THEN 'BUY'	-- When the shorter moving average is higher than the longer moving average, it is a signal to BUY.
		WHEN (`20 Day MA` < `50 Day MA`)   THEN 'SELL'	-- When the longer moving average is higher than the shorter moving average, it is a signal to SELL.
		ELSE 'HOLD'		-- If the signal is neither buy nor sell, it is meant to be in hold.
	END AS `Signal`
FROM eicher1 ;

SELECT * FROM eicher2;

-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

-- hero2
USE Assignment;
SET SQL_SAFE_UPDATES = 0;	-- Setting Safe Update mode off
DROP TABLE IF EXISTS hero2;
CREATE TABLE IF NOT EXISTS hero2 AS		-- Creating a table having Date, close_price and a Signal whether to Buy/Sell/Hold
SELECT `Date`, Close_Price AS `Close Price`,
	CASE
		WHEN (`20 Day MA` > `50 Day MA`)   THEN 'BUY'	-- When the shorter moving average is higher than the longer moving average, it is a signal to BUY.
		WHEN (`20 Day MA` < `50 Day MA`)   THEN 'SELL'	-- When the longer moving average is higher than the shorter moving average, it is a signal to SELL.
		ELSE 'HOLD'		-- If the signal is neither buy nor sell, it is meant to be in hold.
	END AS `Signal`
FROM hero1;

SELECT * FROM hero2;

-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

-- infosys2
USE Assignment;
SET SQL_SAFE_UPDATES = 0;	-- Setting Safe Update mode off
DROP TABLE IF EXISTS infosys2;
CREATE TABLE IF NOT EXISTS infosys2 AS	-- Creating a table having Date, close_price and a Signal whether to Buy/Sell/Hold
SELECT `Date`, Close_Price AS `Close Price`,
	CASE
		WHEN (`20 Day MA` > `50 Day MA`)   THEN 'BUY'	-- When the shorter moving average is higher than the longer moving average, it is a signal to BUY.
		WHEN (`20 Day MA` < `50 Day MA`)   THEN 'SELL'	-- When the longer moving average is higher than the shorter moving average, it is a signal to SELL.
		ELSE 'HOLD'		-- If the signal is neither buy nor sell, it is meant to be in hold.
	END AS `Signal`
FROM infosys1;

SELECT * FROM infosys2;

-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

-- tcs2
USE Assignment;
SET SQL_SAFE_UPDATES = 0;	-- Setting Safe Update mode off
DROP TABLE IF EXISTS tcs2;
CREATE TABLE IF NOT EXISTS tcs2 AS	-- Creating a table having Date, close_price and a Signal whether to Buy/Sell/Hold
SELECT `Date`, Close_Price AS `Close Price`,
	CASE
		WHEN (`20 Day MA` > `50 Day MA`)   THEN 'BUY'	-- When the shorter moving average is higher than the longer moving average, it is a signal to BUY.
		WHEN (`20 Day MA` < `50 Day MA`)   THEN 'SELL'	-- When the longer moving average is higher than the shorter moving average, it is a signal to SELL.
		ELSE 'HOLD'		-- If the signal is neither buy nor sell, it is meant to be in hold.
	END AS `Signal`
FROM tcs1;

SELECT * FROM tcs2;

-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

-- tvs2
USE Assignment;
SET SQL_SAFE_UPDATES = 0;	-- Setting Safe Update mode off
DROP TABLE IF EXISTS tvs2;
CREATE TABLE IF NOT EXISTS tvs2 AS	-- Creating a table having Date, close_price and a Signal whether to Buy/Sell/Hold
SELECT `Date`, Close_Price AS `Close Price`,
	CASE
		WHEN (`20 Day MA` > `50 Day MA`)   THEN 'BUY'	-- When the shorter moving average is higher than the longer moving average, it is a signal to BUY.
		WHEN (`20 Day MA` < `50 Day MA`)   THEN 'SELL'	-- When the longer moving average is higher than the shorter moving average, it is a signal to SELL.
		ELSE 'HOLD'		-- If the signal is neither buy nor sell, it is meant to be in hold.
	END AS `Signal`
FROM tvs1;

SELECT * FROM tvs2;

-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~