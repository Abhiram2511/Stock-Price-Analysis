-- 4. Create a User defined function, that takes the date as input and returns the signal for that particular day (Buy/Sell/Hold) for the Bajaj stock.

USE Assignment;
SET SQL_SAFE_UPDATES = 0;	-- Setting Safe Update mode off
-- Dropping the User Defined Function if it already exists
DROP FUNCTION IF EXISTS Bajaj_Stock_Signal;
-- Creating the User Defined Function to get Signal Buy/Sell/Hold of a specific user desired date
DELIMITER $$
CREATE FUNCTION Bajaj_Stock_Signal(user_input_date date) 
  RETURNS VARCHAR(20)
  DETERMINISTIC
BEGIN
RETURN (SELECT `Signal` FROM `bajaj2` WHERE `Date` = user_input_date);
END $$
DELIMITER ;

-- Test the above created user defined function with some random dates
-- Now testing on the date "2015-01-05", expecting the signal to "BUY"
SELECT Bajaj_Stock_Signal("2015-01-05") as `Signal`;

-- Now testing on the date "2015-02-05", expecting the signal to "SELL"
SELECT Bajaj_Stock_Signal("2015-02-05") as `Signal`;

-- Now finally testing on the date "2015-04-01", expecting the signal to "HOLD"
SELECT Bajaj_Stock_Signal("2015-04-01") as `Signal`;
